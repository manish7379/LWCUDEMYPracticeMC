import { LightningElement, api, wire,track } from 'lwc';
import {registerListener,unregisterAllListeners} from 'c/pubsub';
import {CurrentPagereference} from 'lightning/navigation';
export default class SelectedMeetingRoom extends LightningElement {
    @track selectedMeetingRoom ={};
    @wire(CurrentPagereference) pageRef;
    connectedCallback(){
        registerListener('pubsubclick',this.onMeetingRommHandler,this);
    }
    disconnectedCallback(){
        unregisterAllListeners(this);
    }
    onMeetingRommHandler(payload){
        this.selectedMeetingRoom =payload;
    }
}