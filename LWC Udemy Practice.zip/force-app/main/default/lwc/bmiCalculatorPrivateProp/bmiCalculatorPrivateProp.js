import { LightningElement,track } from 'lwc';

export default class BmiCalculatorPrivateProp extends LightningElement {
    @track bmiResult;
    weight;
    height;
    inputHandler(event){
        const inputName=event.target.name;
        if(inputName==='Weight'){
            this.weight=parseFloat(event.target.value);
        }
        else if(inputName==='Height'){
            this.height=parseFloat(event.target.value);
        }
        
    }
    
    bmiHandler(){
        try{
        this.bmiResult=this.weight/(this.height*this.height);
        }
        catch(error){
            alert('Provide correct values');
            this.bmiResult=undefined;
        }
    }
    get bmiValue(){
        if(this.bmiResult===undefined){
            return "";
        }
        return `Your BMI is : ${this.bmiResult}`;
    }
}