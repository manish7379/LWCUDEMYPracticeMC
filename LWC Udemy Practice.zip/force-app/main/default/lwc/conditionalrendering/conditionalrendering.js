import { LightningElement ,track} from 'lwc';

export default class Conditionalrendering extends LightningElement {
    @track displayDiv=false;
    @track cityList=['agra','delhi','mumbai'];
    showdivHandler(event){
        this.displayDiv=event.target.checked;
    }
}