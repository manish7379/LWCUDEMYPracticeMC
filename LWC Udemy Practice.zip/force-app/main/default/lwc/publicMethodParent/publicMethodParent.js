import { LightningElement, track } from 'lwc';

export default class PublicMethodParent extends LightningElement {
    @track value;
    valueChangeHandler(event){
        this.value=event.target.value;
    }

    selectCheckboxHandler(){
        const childCmp= this.template.querySelector('c-public-method-child');
        const returnmessge= childCmp.slectCheckBox(this.value);
        console.log(returnmessge);
    }
}