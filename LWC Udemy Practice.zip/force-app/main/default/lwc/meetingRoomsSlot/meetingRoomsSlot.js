import { LightningElement,api } from 'lwc';

export default class MeetingRoomsSlot extends LightningElement {
    //@api meetingRoomInfo;
    @api showRoom=false;
}