import { LightningElement,api,track} from 'lwc';

export default class MeetingRoomSlots extends LightningElement {
    @api meetingRoomsInfo=[
        {roomName:'A-01',roomCapacity:12},
        {roomName:'A-02',roomCapacity:15},
        {roomName:'A-03',roomCapacity:17},
        {roomName:'A-04',roomCapacity:18}
    ];
    @track showRooms=false;
    showRoomhandler(event){
        this.showRooms=event.target.checked;
    }
}