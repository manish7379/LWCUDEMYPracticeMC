import { LightningElement,track,api } from 'lwc';

export default class PublicMethodChild extends LightningElement {
    @track value = ['red'];
    options=[
        { label: 'Red Marker', value: 'red' },
        { label: 'Blue Marker', value: 'blue' },
        { label: 'Green Marker', value: 'green' },
        { label: 'Black Marker', value: 'black' }
    ];
    @api
   slectCheckBox(checkBoxValue){
       const selectedCheckBox=this.options.find(checkbox=>{
           return checkBoxValue===checkbox.value;
       })
       if(selectedCheckBox){
           this.value=selectedCheckBox.value;
           return "Successfully checked"
       }
       else{
           return "No checkbox found"
       }
   }

}