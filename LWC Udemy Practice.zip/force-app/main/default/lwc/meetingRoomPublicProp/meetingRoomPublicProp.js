import { LightningElement,api,wire } from 'lwc';
import {fireEvent} from 'c/pubsub';
import {CurrentPagereference} from 'lightning/navigation';
export default class MeetingRoomPublicProp extends LightningElement {
    @api meetingRoomInfo;
    @api showRoom=false;
    @wire(CurrentPagereference) pageReference;
    tileClickHandler(){
        const tileClicked= new CustomEvent('tileclick',{detail:this.meetingRoomInfo});
        this.dispatchEvent(tileClicked);
        fireEvent(this.pageref,'pubsubclick',this.meetingRoomInfo);
    }
}