import { LightningElement,track } from 'lwc';

export default class SimpleCalculator extends LightningElement {
    @track resultData;
    @track previousResult=[];
    @track showPreviousresult=false;
    firstNumber;
    secondNumber;
    numberChangehandler(event){
        const inputBoxname=event.target.name;
        if(inputBoxname==='first Number'){
            this.firstNumber=event.target.value;
        }
        else if(inputBoxname==='Second Number'){
            this.secondNumber=event.target.value;
        }

    }
    addhandler(){
        const firstN=parseInt(this.firstNumber);
        const secondN=parseInt(this.secondNumber);
        this.resultData=`result of ${firstN} + ${secondN} is equal to ${firstN +secondN}`;
        this.previousResult.push(this.resultData);
    
    }
    substracthandler(){
        const firstN=parseInt(this.firstNumber);
        const secondN=parseInt(this.secondNumber);
        this.resultData=`result of ${firstN} - ${secondN} is equal to ${firstN -secondN}`;
        this.previousResult.push(this.resultData);
    
    }
    multiplyhandler(){
        const firstN=parseInt(this.firstNumber);
        const secondN=parseInt(this.secondNumber);
        this.resultData=`result of ${firstN} * ${secondN} is equal to ${firstN *secondN}`;
        this.previousResult.push(this.resultData);
    
    }
    dividehandler(){
        const firstN=parseInt(this.firstNumber);
        const secondN=parseInt(this.secondNumber);
        this.resultData=`result of ${firstN} / ${secondN} is equal to ${firstN /secondN}`;
        this.previousResult.push(this.resultData);
    
    }
    showPreviousresultHandler(event){
        this.showPreviousresult=event.target.checked;
    }
}