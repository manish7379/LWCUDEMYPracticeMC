import { LightningElement,api,track } from 'lwc';

export default class MeetingRooms extends LightningElement {
    @track selectedMeetingRoom;
    @api meetingRoomsInfo=[
        {roomName:'A-01',roomCapacity:12},
        {roomName:'A-02',roomCapacity:15},
        {roomName:'A-03',roomCapacity:17},
        {roomName:'A-04',roomCapacity:18}
    ];
    @track showRooms=false;
    showRoomhandler(event){
        this.showRooms=event.target.checked;
    }
    tileSelectHandler(event){
        const meetingRoomsInfo=event.detail;
        this.selectedMeetingRoom=meetingRoomsInfo.roomName;

    }
   /* constructor(){
        super();
        this.template.addEventListener('tileclick',this.tileSelectHandler.bind(this));
    } // the change in child cmp {detail:this.meetingRoomInfo,bubbles:true} and remove call handler from child cmp in parent cmp 
*/
}