import { LightningElement,track } from 'lwc';

export default class Testlwc extends LightningElement {
    @track dyanamicGreeting='World';
    greetingHandler(evnt){
        this.dyanamicGreeting=evnt.target.value;
    }
}